import {addItem, differentFruits} from "./shoppinglist.js";


addItem("banana");
differentFruits();